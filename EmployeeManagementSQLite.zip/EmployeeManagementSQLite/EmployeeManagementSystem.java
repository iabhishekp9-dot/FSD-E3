import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class EmployeeManagementSystem {
    // SQLite database file path
    static String url = "jdbc:sqlite:C:/Users/vinee/Downloads/employees.db";
    static Connection conn;

    public static void main(String[] args) throws Exception {
        // Load SQLite JDBC Driver
        Class.forName("org.sqlite.JDBC");

        // Connect to SQLite Database
        conn = DriverManager.getConnection(url);
        System.out.println("Connected to SQLite database.");

        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\nEmployee Management System");
            System.out.println("1. Add Employee");
            System.out.println("2. View Employees");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    addEmployee(conn);
                    break;
                case 2:
                    viewEmployees(conn);
                    break;
                case 3:
                    System.out.println("Exiting...");
                    conn.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addEmployee(Connection conn) throws SQLException {
        Scanner s = new Scanner(System.in);
        System.out.println("\nAdding Employee");
        System.out.print("Enter employee id: ");
        int eno = s.nextInt();
        System.out.print("Enter employee name: ");
        String name = s.next();
        System.out.print("Enter employee salary: ");
        int salary = s.nextInt();

        PreparedStatement pstmt = conn.prepareStatement("INSERT INTO emp (id, name, salary) VALUES (?, ?, ?)");
        pstmt.setInt(1, eno);
        pstmt.setString(2, name);
        pstmt.setInt(3, salary);
        pstmt.executeUpdate();
        System.out.println("Employee added successfully.");
    }

    private static void viewEmployees(Connection conn) throws SQLException {
        System.out.println("\nList of Employees");
        String sql = "SELECT * FROM emp";
        try (PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                int salary = rs.getInt("salary");
                System.out.println("ID: " + id + ", Name: " + name + ", Salary: " + salary);
            }
        }
    }
}